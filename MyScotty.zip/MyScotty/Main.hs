{-# LANGUAGE OverloadedStrings #-}
import Web.Scotty

import Text.Blaze.Html5
import Text.Blaze.Html5.Attributes
import qualified Web.Scotty as S
import qualified Text.Blaze.Html5 as H
import qualified Text.Blaze.Html5.Attributes as A

import Text.Blaze.Html.Renderer.Text

-- module Views.Todo where
import qualified Views.Todo
import qualified Views.Info
blaze = S.html . renderHtml

main = do
  scotty 3000 $ do
    get "/" $ do
      S.html . renderHtml $ do
        h1 "Hello from Scotty Framework!"
        h3 "Haskell rulezz!"
        p $ do
            img ! src "static/haskell-logo.jpg" ! alt "Logo of Haskell"
        ul $ do
          li $ do a ! href "/" $ em "Home"
          li $ do a ! href "/info" $ em "Info"
          li $ do a ! href "/todo" $ em "Todo"
        p "This page create with Haskell & Blaze-html for Scotty Framework"
    get "/info" $ do
      blaze Views.Info.render
    get "/todo" $ do
      blaze Views.Todo.render
    notFound $ file "Views/404.html"


# About project

MyScotty is project where I learning create sites with haskell and Scotty Framework

---

cabal sandbox init

cabal update

cabal install

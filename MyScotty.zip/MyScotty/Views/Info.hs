{-# LANGUAGE OverloadedStrings #-}

module Views.Info where

import Prelude hiding (div, head, id)
import Text.Blaze.Html (Html, toHtml)
import Text.Blaze.Html5 (Html, a, body, button, em,
  dataAttribute, div, docTypeHtml,
  form, h1, h2, head, input, li,
  link, meta, p, script, style,
  title, ul, (!))
import Text.Blaze.Html5.Attributes (charset, class_, content, href,
  httpEquiv, id, media, name,
  placeholder, rel, src, type_)

render = do
    body $ do
      h1 "Info"
      ul $ do
        li $ do a ! href "/" $ em "Home"
        li $ do a ! href "/info" $ em "Info"
        li $ do a ! href "/todo" $ em "Todo"
      h1 "Тестовое приложение на Scotty framework!"
      p "Этот сайт является приложением для изучения мной возможностей Haskell для веба на примере веб-фреймворка Scotty."
      h2 "Почему Haskell?"
      ul $ do
        li "Я - одессит, а в Одессе есть Haskell user group. :) "
        li "Начал читать кнужку Шевченко 'О Haskell по-человечески', и мне таки понравилось."
        li "Слышал, что хаскель крут и что на нем можно программить чуть ли не все, что угодно..."


import Graphics.Element exposing (..)

-- a simple function to check if n is evem
isEven : Int -> Bool
isEven n = n % 2 == 0

-- defining a simple function that squares numbers
sqr : Int -> Int
sqr n =
    n*n

-- convert temperature in Centigrade to Fahrenheit
centigradeToFahrenheit : Float -> Float
centigradeToFahrenheit c =
    c * 9/5 + 32

add : Int -> Int -> Int
add a b =
    a + b

increment : Int -> Int
increment n = n + 1






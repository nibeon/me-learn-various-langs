import Html

main : Html.Html
main = 
    Html.text "Hello"

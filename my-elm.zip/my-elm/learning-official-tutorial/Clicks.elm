-- программа определяет клики мыши

module Main (..) where

import Html exposing (Html)
import Mouse

view : Int -> Html
view count = 
    Html.text (toString count)
    
countSignal : Signal Int
countSignal = 
    -- Signal.map (always 1) Mouse.clicks -- всегда отображает 1
    Signal.foldp (\_ state -> state + 1) 0 Mouse.clicks -- определяет сколько кликов и меняет состояние
    
main : Signal.Signal Html
main = 
    Signal.map view countSignal
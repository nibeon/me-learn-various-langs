# PureScript 0.6.9.5

## for Windows 32-bit

### Compiled on Windows 7 32-bit SP1


Only binaries

# hello-purescript

Simply Hello World application on PureScript 0.6.9.5
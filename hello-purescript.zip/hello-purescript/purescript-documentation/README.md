# PureScript Documentation

### for Release 0.5.0


Документация PureScript для версии 0.5.0

***от 30 октября 2014***

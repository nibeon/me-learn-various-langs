module Main where

-- конструктор типа User
data User = User {
    firstName, lastName, email, yearOfBirth    :: String ,
    account, uid :: Integer
} deriving Show

main =
    print user
    where user = User {
        firstName = "Denis",
        lastName = "Shevchenko",
        email = "me@dshevchenko.biz",
        yearOfBirth = "1981",
        account = 1234567890,
        uid = 123
    }


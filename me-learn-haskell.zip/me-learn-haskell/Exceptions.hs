module Main where

import Control.Exception

tryToOpenFile :: FilePath -> IO String
tryToOpenFile path = 
    readFile path `catch` possibleErrors
    where
        possibleErrors :: IOException -> IO String
        possibleErrors error = return $ show error
        
main :: IO()
main = do
    fileContent <- tryToOpenFile "Users/shevchenko/test.c" -- попытка прочитать несуществующий файл
    putStrLn fileContent

----------------------------------

-- P.S. handle - альтернатива catch
-- catch принимает обработчик вторым по счёту, а handle - первым. Таким образом, catch читабельнее в инфиксной форме, а handle - в простой. Так что выбирайте на вкус.

--tryToOpenFile :: FilePath -> IO String
--tryToOpenFile path =
--  handle possibleErrors (readFile path)  -- То же самое, но наоборот.
--    where
--      possibleErrors :: IOException -> IO String
--      possibleErrors error = return "Aaaaa!!! Please check file."


-- Empty module to serve as the default current module.
module Main where

f :: Int -> Int -> Int
f x y  = x*x + y*y

main = print (f 2 3)
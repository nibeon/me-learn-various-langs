module Main where

type SHU = Integer -- SHU (Scoville Heat Units), единица жгучести перца

-- свой класс типов
class Pepper p where
    color :: p -> String -- цвет перца
    pungency :: p -> SHU -- жгучесть перца
    
data Poblano = Poblano -- мексиканский перец

data TrinidadScorpion  = TrinidadScorpion -- самый жгучий перец в мире

instance Pepper Poblano where 
    color Poblano = "green"
    pungency Poblano = 1500
    
instance Pepper TrinidadScorpion where 
    color TrinidadScorpion = "red"
    pungency TrinidadScorpion = 855000
 
-- Определим функцию, выводящую информацию о конкретном перце:
pepperInfo :: Pepper p => p -> String
pepperInfo pepper = show (pungency pepper) ++ ", " ++ color pepper

-- контекст может состоять и из нескольких классов, которые перечисляются в виде кортежа:
class (Pepper p, Capsicum p) => Chili p where
    kind :: p -> String

main = 
    putStrLn $ show (pungency trinidad) ++ ", " ++ color trinidad 
    where trinidad = TrinidadScorpion

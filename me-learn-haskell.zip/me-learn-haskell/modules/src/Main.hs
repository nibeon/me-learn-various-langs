module Main where

-- import Utils.Helpers (calibrate) -- Импортируем только calibrate.

import Utils.Helpers hiding (graduate) -- graduate скрыта

main :: IO()
main = print $ calibrate 12.4

module Main where

duplicateFirstElement :: [a] -> [a]
duplicateFirstElement (x : xs) = x : x : xs

main :: IO ()
main = print $ duplicateFirstElement [23, 45, 67]
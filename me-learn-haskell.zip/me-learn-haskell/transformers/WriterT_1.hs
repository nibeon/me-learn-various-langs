module Main where

import Control.Monad.Writer.Lazy
import System.Directory
import System.FilePath
--import System.Posix

type Environment = String
type FileInfoCloud = WriterT Environment IO String

obtainLanguage :: FilePath -> FileInfoCloud
obtainLanguage path = do
    tell $ case takeExtension path of
        ".c" -> "C, "
        ".cpp" -> "C++, "
        ".hs" -> "Haskell, "
        ".py" -> "Python, "
        _ -> "Unknown, "
    return path
    
obtainModificationDate :: FilePath -> FileInfoCloud
obtainModificationDate path = do 
    date <- liftIO $ getModificationDate path 
    tell $ show date ++ ", "
    return path
    
obtainSize :: FilePath -> FileInfoCloud
obtainSize path = do 
    status <- liftIO $ getFileStatus path
    tell $ (show $ fileSize status) ++ " bytes"
    return path
    
main :: IO()
main = do
    let path "ReaderT.hs"
    info <- execWriterT $ obtainLanguage path
                          >>= obtainModificationDate
                          >>= obtainSize
    putStrLn $ "Info about " ++ path ++ ":\n"
               ++ info

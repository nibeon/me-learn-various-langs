module Main where

import Control.Monad.Error

type ErrorMessage = String
type Length = Int
type LengthMonad = ErrorT ErrorMessage IO Length

calculateLength :: LengthMonad
calculateLength = do
    liftIO $ putStrLn "Please enter a non-empty string: "
    stringFromUser <- liftIO getLine
    if null stringFromUser
    then throwError "the string is empty!"  -- Записываем в "облако" ошибку... 
    else return $ length stringFromUser     -- Всё в порядке, записываем длину...

main :: IO ()
main = do
    result <- runErrorT calculateLength
    putStrLn $ case result of
        Left error -> "Hm... Error occured: " ++ error
        Right length -> "The length is " ++ show length
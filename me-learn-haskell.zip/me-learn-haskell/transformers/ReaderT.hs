-- without Reader
module Main where

gitRoot = "/.git/"

getPathToBranches :: String -> String
getPathToBranches pathToRepo = 
    "Branches: " ++ pathToRepo ++ gitRoot ++ "branches"
    
getPathToHooks :: String -> String
getPathToHooks pathToRepo = 
    "Hooks: " ++ pathToRepo ++ gitRoot ++ "hooks"
    
getPathToLogs :: String -> String
getPathToLogs pathToRepo = 
    "Logs: " ++ pathToRepo ++ gitRoot ++ "logs"
    
getPathToObjects :: String -> String
getPathToObjects pathToRepo = 
    "Objects: " ++ pathToRepo ++ gitRoot ++ "objects"
    
getPathToRefs :: String -> String
getPathToRefs pathToRepo = 
    "Refs: " ++ pathToRepo ++ gitRoot ++ "refs"
    
getPathToInfo :: String -> String
getPathToInfo pathToRepo = 
    "Info: " ++ pathToRepo ++ gitRoot ++ "info"
    
showRepoInternalDirectories :: String -> String
showRepoInternalDirectories pathToRepo = 
    let pathToBranches = getPathToBranches pathToRepo
        pathToHooks = getPathToHooks pathToRepo
        pathToLogs = getPathToLogs pathToRepo
        pathToObjects = getPathToObjects pathToRepo
        pathToRefs = getPathToRefs pathToRepo
        pathToInfo = getPathToInfo pathToRepo
    in 
    concat [pathToBranches 
            ,"\n", pathToHooks 
            ,"\n", pathToLogs 
            ,"\n", pathToObjects 
            ,"\n", pathToRefs 
            ,"\n", pathToInfo]
            
main :: IO()
main = do 
    pathToRepo <- readFile "/Users/dshevchenko/my.conf"
    let pathWithoutTrailingNL = takeWhile (/= '\n') pathToRepo
        finalInfo = showRepoInternalDirectories pathWithoutTrailingNL
    putStrLn finalInfo

module Main where

import Control.Monad.Trans.Either
import Control.Monad.IO.Class 

type ErrorMessage = String
type Length = Int
type LengthMonad = EitherT ErrorMessage IO Length

calculateLength :: LengthMonad
calculateLength = do
    liftIO $ putStrLn "Please enter a non-empty string: "
    stringFromUser <- liftIO getLine
    if null stringFromUser
    then left "the string is empty!"
    else right $ length stringFromUser

main :: IO ()
main = do
    result <- runEitherT calculateLength
    putStrLn $ case result of
        Left error -> "Hm... Error occured: " ++ error
        Right length -> "The length is " ++ show length
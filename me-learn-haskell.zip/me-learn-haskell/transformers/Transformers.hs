module Main where

emailIsValid :: String -> Bool
-- Пусть наличие '@' будет нашим единственным
-- критерием корректности почтового адреса.
emailIsValid email = '@' `elem` email 

getEmail :: IO (Maybe String)
getEmail = do
    email <- getLine -- что-то получаем от пользователя
    return $ if emailIsValid email 
        then Just email -- всё ОК
        else Nothing    -- нет, ерунда какая-то
        
main :: IO()
main = do
    putStrLn "Input your email, please: "
    email <- getEmail
    -- проверка введенного
    case email of 
        Nothing -> putStrLn "Wrong email!"
        Just email -> putStrLn $ "OK, your email is " ++ email 

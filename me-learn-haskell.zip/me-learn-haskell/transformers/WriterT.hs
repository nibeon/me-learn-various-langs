import Control.Monad.Writer.Lazy
import Data.Char
import Data.String.Utils

type Environment = String
type LoggingCloud = Writer Environment String

addPrefix :: String -> LoggingCloud
addPrefix url = do
    tell "addPrefix... "
    return $ if url `startsWith` prefix then url else prefix ++ url
    where prefix = "http://"
          startsWith url prefix = startswith prefix url

encodeAllSpaces :: String -> LoggingCloud
encodeAllSpaces url = do
    tell "encodeAllSpaces... "
    return $ replace " " "%20" url

makeItLowerCase :: String -> LoggingCloud
makeItLowerCase url = do
    tell "makeItLowerCase... "  -- Сохраняем в логирующее облако...
    return $ map toLower url    -- ... и туда же кладём наш изменённый URL...

main :: IO ()
main = do
    let url = "www.SITE.com/test me/Start page"
        result = runWriter $ addPrefix url
                             >>= encodeAllSpaces
                             >>= makeItLowerCase
        correctedUrl = fst result
        log = snd result
    putStrLn $ "Corrected URL: " ++ correctedUrl ++ "\n" ++
               "Log: " ++ log

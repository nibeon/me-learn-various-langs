-- способ с MaybeT
module Main where

import Control.Monad.Trans.Maybe
import Control.Monad.Trans.Class
import Control.Monad

emailIsValid :: String -> Bool
emailIsValid email = '@' `elem` email 

getEmail :: MaybeT IO String
getEmail = do
    email <- lift getLine
    guard $ emailIsValid email
    return email

main :: IO ()
main = do
    putStrLn "Input your email, please:"
    email <- runMaybeT getEmail
    case email of
        Nothing -> putStrLn "Wrong email."
        Just email -> putStrLn $ "OK, your email is " ++ email

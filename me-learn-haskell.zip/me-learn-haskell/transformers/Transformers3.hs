module Main where

import Control.Monad.Trans.Either
import Control.Monad.IO.Class 
import System.Environment 

type ErrorMessage = String
type EnvironmentInfo = EitherT ErrorMessage IO ()

checkCppCompiler :: EnvironmentInfo
checkCppCompiler = do
    -- Анализируем переменную среды...
    maybeCxx <- liftIO $ lookupEnv "CXX"
    case maybeCxx of
        Nothing -> left "CXX compiler not found!"
        Just _ -> right ()  -- Всё в порядке, записываем "пустоту"...

checkCCompiler :: EnvironmentInfo
checkCCompiler = do
    -- И ещё одну переменную среды...
    maybeC <- liftIO $ lookupEnv "CC"
    case maybeC of
        Nothing -> left "CC compiler not found!"
        Just _ -> right ()  -- Всё в порядке, записываем "пустоту"...

main :: IO ()
main = do
    result <- runEitherT $ checkCppCompiler >> checkCCompiler
    putStrLn $ case result of
        Left error -> "Fault: " ++ error
        Right _ -> "OK."
module Main where

import Control.Monad.Reader

type Environment = String
type PathReader = Reader Environment String

gitRoot = "/.git/"

getPathToBranches :: PathReader
getPathToBranches = do 
    pathToRepo <- ask
    return $ "Branches: " ++ pathToRepo ++ gitRoot ++ "branches"
    
getPathToHooks :: String -> String
getPathToHooks pathToRepo = 
    "Hooks: " ++ pathToRepo ++ gitRoot ++ "hooks"
    
getPathToLogs :: String -> String
getPathToLogs pathToRepo = 
    "Logs: " ++ pathToRepo ++ gitRoot ++ "logs"
    
getPathToObjects :: String -> String
getPathToObjects pathToRepo = 
    "Objects: " ++ pathToRepo ++ gitRoot ++ "objects"
    
getPathToRefs :: String -> String
getPathToRefs pathToRepo = 
    "Refs: " ++ pathToRepo ++ gitRoot ++ "refs"
    
getPathToInfo :: String -> String
getPathToInfo pathToRepo = 
    "Info: " ++ pathToRepo ++ gitRoot ++ "info"
    
showRepoInternalDirectories :: PathReader 
showRepoInternalDirectories = do
    pathToBranches <- getPathToBranches
    pathToHooks <- getPathToHooks
    pathToLogs <- getPathToLogs
    pathToObjects <- getPathToObjects
    pathToRefs <- getPathToRefs
    pathToInfo <- getPathToInfo
    return $ concat [pathToBranches
                     ,"\n", pathToHooks 
                     ,"\n", pathToLogs 
                     ,"\n", pathToObjects 
                     ,"\n", pathToRefs 
                     ,"\n", pathToInfo]
            
main :: IO()
main = do 
    pathToRepo <- readFile "/Users/dshevchenko/my.conf"
    let pathWithoutTrailingNL = takeWhile (/= '\n') pathToRepo
        -- runReader сразу вернёт String, а не IO String... 
        finalInfo = runReader showRepoInternalDirectories 
                              pathWithoutTrailingNL
    putStrLn finalInfo

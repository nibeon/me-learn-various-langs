module Main where

import Data.Char

main :: IO()
main = 
    print $ numbers >>= toRealNumbers 
    where numbers = "1234567890" 
          toRealNumbers = return . digitToInt

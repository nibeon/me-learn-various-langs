module Main where

newtype Distance value = Distance value deriving Show

instance Functor Distance where 
    fmap magicWand(Distance value) = Distance (magicWand value)

instance Applicative Distance where
    Distance magicWand <*> functor = fmap magicWand functor
 

main :: IO()
main = print $ (+) <$> Distance 19.78 <*> Distance 1.6 -- это для сложения (+), для вычитания (-), умножения (*) и т.д.

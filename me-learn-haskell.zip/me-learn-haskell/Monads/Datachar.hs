module Main where

import Data.Char

toLowerCase = return . toLower

underlineSpaces char = return $ if char == ' ' then '_' else char

main :: IO()
main = 
    print $ name >>= toLowerCase >>= underlineSpaces
    where name = "Lorem ipsuM"

module Main where

obtainTwoTextsFromUser :: IO String
obtainTwoTextsFromUser =     
    (++) <$> getFirstText <*> getSecondText  -- Складываем строки.  
    where getFirstText = putStrLn "Enter your text, please: " *> getLine
          getSecondText = putStrLn "One more, please: " *> getLine

main :: IO ()
main = do
    twoTexts <- obtainTwoTextsFromUser
    putStrLn $ "You said " ++ twoTexts

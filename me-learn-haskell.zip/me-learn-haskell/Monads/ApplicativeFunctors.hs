module Main where

newtype Distance value = Distance value deriving Show

add (Distance a) (Distance b) = Distance (a + b)
minus (Distance a) (Distance b) = Distance (a - b)

main :: IO()
main = print $ Distance 19.78 `add` Distance 1.6
-- для вічитания Distance 19.78 `minus` Distance 1.6

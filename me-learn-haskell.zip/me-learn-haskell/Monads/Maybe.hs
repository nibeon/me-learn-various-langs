module Main where

import Data.Char

coefficientFromString :: String -> Maybe Int
coefficientFromString str = 
    if isNumber firstChar then Just (digitToInt firstChar) else Nothing
    where firstChar = str !! 0 -- извлекаем символ с индексом 0
    
check :: Maybe Int -> String
check aCoefficient
    | aCoefficient == Nothing = "Invalid string!"
    | otherwise = show aCoefficient
    
main :: IO()
main = print $ check $coefficientFromString "12345" -- выведет "Just 1"

{-# LANGUAGE NoMonomorphismRestriction #-}

module Main where

import Data.Char

toLowerCase = return . toLower

main :: IO()
main = 
    print $ name >>= toLowerCase 
    where name = Just 'A'

module Main where

newtype Distance value = Distance value deriving Show

instance Functor Distance where 
    fmap magicWand(Distance value) = Distance (magicWand value)

instance Applicative Distance where
    Distance magicWand <*> functor = fmap magicWand functor
    pure magicWand = Distance magicWand
 

main :: IO()
main = print $ pure totalSum <*> Distance 19.78 
                        <*> Distance 1.6 
                        <*> Distance 289.0 
                        *> Distance 2.0 -- Цепочка уже разорвалась, поэтому выведет Distance 2.0
            where totalSum arg1 arg2 arg3 = arg1 + arg2 + arg3

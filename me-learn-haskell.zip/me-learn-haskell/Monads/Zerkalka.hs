-- зеркальная компоновка
module Main where

import Data.Char

toLowerCase = return . toLower

underlineSpaces char = return $ if char == ' ' then '_' else char

main :: IO()
main = 
    print $ toLowerCase =<< underlineSpaces =<< name 
    where name = "Lorem ipsuM"

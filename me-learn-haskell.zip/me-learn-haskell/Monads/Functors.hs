module Main where

data Year value = Year value deriving Show

instance Functor Year where
    fmap magicWand (Year value) = Year (magicWand value)
    
increase :: Int -> Int
increase year = year + 1

main :: IO()
main =
    print $ fmap increase year
    where year = Year 1981

module Main where

takeTwoHeads :: [a] -> [a] -> (a, a)
takeTwoHeads (x : _) (y : _) = (x, y)

main :: IO ()
main = print $ takeTwoHeads [23, 45, 67] [89, 93]
module Main where

main :: IO()
main = print $ head [23, 45, 67]

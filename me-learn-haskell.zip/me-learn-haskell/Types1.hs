module Main where

-- составной тип User
data User = User {
    firstName   :: String ,
    lastName    :: String ,
    email       :: String
}

-- создание видимости изменяемости поля
changeEmail :: User -> String -> User
changeEmail user newEmail = user { email = newEmail}

main =
    let userWithNewEmail = changeEmail user "shev.denis@gmail.com"
    in putStrLn $ email userWithNewEmail
    where user = User { firstName = "Denis" ,
    lastName = "Shevchenko", 
    email = "me@dshevchenko.biz"
    }


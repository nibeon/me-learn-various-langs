module Main where

type SHU = Integer -- SHU (Scoville Heat Units), единица жгучести перца

class Pepper p where
    simple   :: p           -- Это константное значение, а не функция.
    color    :: p -> String
    pungency :: p -> SHU
    name     :: p -> String

data Poblano = Poblano String  -- Унарный конструктор вместо нульарного.

instance Pepper Poblano where
    simple = Poblano "ancho"         -- Готовим простое значение.
    color (Poblano name) = "green"
    pungency (Poblano name) = 1500
    name (Poblano name) = name

main = putStrLn $ name (simple :: Poblano)  -- Обращаемся к значению.

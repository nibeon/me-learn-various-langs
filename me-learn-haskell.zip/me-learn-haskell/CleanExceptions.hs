module Main where

import Control.Exception

main :: IO ()
main = do
    -- чтобы словить исключение из чистой функции
    -- используется функция evaluate
    -- evaluate :: a -> IO a
    result <- try $ evaluate $ 2 `div` 0
                    :: IO (Either SomeException Integer)
    case result of
        Left exception -> putStrLn $ "Fault: " ++ show exception
        Right value -> print value


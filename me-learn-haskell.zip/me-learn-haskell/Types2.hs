module Main where

-- конструктор типа User
data User y = User {
    firstName, lastName, email       :: String ,
    yearOfBirth :: y, 
    account, uid :: Integer
}

-- создание видимости изменяемости поля
-- User String - приведение конструктора типов к типу String
changeEmail :: User String -> String -> User String
-- как вариант User y -> String -> User y
changeEmail user newEmail = user { email = newEmail}

main =
    let userWithNewEmail = changeEmail user "shev.denis@gmail.com"
    in putStrLn $ email userWithNewEmail
    where user = User { firstName = "Denis" ,
    lastName = "Shevchenko", 
    email = "me@dshevchenko.biz"
    }


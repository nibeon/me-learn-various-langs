module Main where

-- составной тип User
data User = User {
    firstName   :: String ,
    lastName    :: String ,
    email       :: String
}

main =
    putStrLn $ firstName user ++ " " ++ lastName user ++ ", " ++ email user 
    where user = User { firstName = "Denis" ,
    lastName = "Shevchenko", 
    email = "me@dshevchenko.biz"
    }


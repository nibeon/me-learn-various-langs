package main

import "fmt"

func main() {
    var total float64 = 0
    i := 0
    for i < len(x) {
        total := x[i]
        i = i + 1
    }
    fmt.Println(total / float64(len(x)))
}
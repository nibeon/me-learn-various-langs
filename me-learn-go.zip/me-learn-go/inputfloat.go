package main

import "fmt"

func main() {
    fmt.Print("Введите число: ")
    var input float64
    fmt.Scanf("%f", &input)
    
    output := input * 2
    
    fmt.Println("Если Ваше число умножить на 2, то получится", output)
}
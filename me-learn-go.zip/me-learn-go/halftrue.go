package main

import "fmt"

func half(x int) bool {
  a := x/2
  if a * 2 == x && a % 2 == 0 {
    return true
  } else {
    return false
  }
}

func main() {
  fmt.Println(half(4)) // true
  fmt.Println(half(5)) // false
  fmt.Println(half(22)) // false
  fmt.Println(half(333)) // false
  fmt.Println(half(444)) // true
}
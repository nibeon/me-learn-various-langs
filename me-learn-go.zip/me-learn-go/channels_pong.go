package main

import (
    "fmt"
    "time"
)

func pinger(c chan string) {
    for i := 0; ; i++ {
        // организовываем прослушку каналов
        c <- "ping"
    }
}

func ponger(c chan string) {
    for i := 0; ; i++ {
        c <- "pong"
    }
}

func printer(c chan string) {
    for {
        msg := <- c // запись прослушиваемого канала в переменную ьып
        fmt.Println(msg) // вывод того, что прослушивается
        time.Sleep(time.Second * 1) // ждем одну секунду
    }
}

func main() {
    var c chan string = make(chan string) // создаем канал
    
    // прослушиваем и печатаем то, что он посылает
    go pinger(c)
    go ponger(c)
    go printer(c) // выдает ping pong по очереди
    
    var input string
    fmt.Scanln(&input) // для остановки канала нажать "enter"
}
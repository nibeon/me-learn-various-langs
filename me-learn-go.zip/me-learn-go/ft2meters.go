// программа перевода футов в метры
package main

import "fmt"
/*
var celcium, farenheit float64

func convert(farenheit, celcium) {
    celcium = (farenheit - 32) * 5/9
}
*/

func main() {
    fmt.Print("Введите количество футов: ")
    var futs float64
    fmt.Scanf("%f", &futs)
    meters := 0.3048 * futs // перевод из футов метры
    fmt.Println("В метрах это ",meters)    
}
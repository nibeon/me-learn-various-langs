package main

import "fmt"

func main() {
  name := "Prince Oberyn"
  age := 32
  location := "Dorne"
  fmt.Printf("%s (%d) of %s", name, age, location)
}
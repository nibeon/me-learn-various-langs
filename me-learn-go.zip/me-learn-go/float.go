package main

import "fmt"

func main() {
    var a = 1.01
    var b = 0.99
    fmt.Println(a - b)
    fmt.Println(1.0 + 1.0)
}
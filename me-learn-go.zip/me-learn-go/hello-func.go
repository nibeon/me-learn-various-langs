package main
import . "fmt"

const Hello = "hello"

func main() {
    Println(Hello, world())
}

func world() string {
    return "world"
}
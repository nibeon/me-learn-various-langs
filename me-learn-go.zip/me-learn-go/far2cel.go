// программа перевода градусов из фаренгейта в цельсии
package main

import "fmt"

func main() {
    fmt.Print("Введите градусы по Фаренгейту: ")
    var fahrenheit float64
    fmt.Scanf("%f", &fahrenheit)
    celcium := (fahrenheit - 32) * 5/9 // перевод из фаренгейты в цельсии
    fmt.Println("В градусах Цельсия это -",celcium)    
}
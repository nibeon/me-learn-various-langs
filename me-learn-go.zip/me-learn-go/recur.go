package main

import "fmt"

func factorial(x uint) uint {
  if x == 0 {
    return 1
  }
  
  return x * factorial(x-1)
}


func fib(n uint) uint {
  if n == 0 {
    return 0
  }
  if n == 1 {
    return 1
  }  
  return fib(n - 1) + fib(n - 2)
}


func main() {
  fmt.Println("Факториал числа 6 равен",factorial(6))
  fmt.Println("Фиббоначи числа 6 равно",fib(6))
}
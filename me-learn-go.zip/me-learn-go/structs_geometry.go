package main

import (
  "fmt"
  "math"
)

type Circle struct {
  x, y, r float64
}

type Rectangle struct {
    x1, y1, x2, y2 float64
}

func distance(x1, y1, x2, y2 float64) float64 {
    a := x2 - x1
    b := y2 - y1
    return math.Sqrt(a*a + b*b)
}

type Shape interface {
  // делаем интерфейс для объединения одинаковых area()
  area() float64
  perimeter() float64 // для периметра фигур
}

func (r *Rectangle) area() float64 {
  // теперь к этой функции со структурой Rectangle можно обращаться с помощью r.area() 
  l := distance(r.x1, r.y1, r.x1, r.y2) // длдяна прямоугольника
  w := distance(r.x1, r.y1, r.x2, r.y1) // ширина прямоугольника
  return l * w
}

func (c *Circle) area() float64 {
  // теперь к этой фукции со структурой Circle можно обращаться через c.area()
  return math.Pi * c.r*c.r
}

// добавление длины окружности ("периметр круга")
func (c *Circle) perimeter() float64 {
  return math.Pi * c.r * 2
}
// добавление периметра прямоугольника
func (r *Rectangle) perimeter() float64 {
  l := distance(r.x1, r.y1, r.x1, r.y2) // длина прямоугольника
  w := distance(r.x1, r.y1, r.x2, r.y1) // ширина прямоугольника
  return l*2 + w*2
}

func totalArea(shapes ...Shape) float64 {
    var area float64
    for _, s := range shapes {
        area += s.area()
    }
    return area
}

// создаем возможность разнообразия возможных интерфейсов для площади
type MultiShape struct {
  shapes []Shape // интерфейсы в качестве полей
}

func (m *MultiShape) area() float64 {
  var area float64
  // вычисляем общую площадь фигур
  for _, s := range m.shapes {
    area += s.area()
  }
  return area
}

func main() {
  c := Circle{0, 0, 5} // передача параметров x, y, r
  fmt.Println("Площадь круга:",c.area()) // вызов функции с переданными параметрами
  r := Rectangle{0, 0, 10, 10} //передача параметров x1, y1, x2, y2
  fmt.Println("Площадь прямоугольника:",r.area()) // вызов функции с переданными параметрами
  fmt.Println("Общая площадь круга и прямоугольника:",totalArea(&c, &r)) //общая площадь для круга (с) и прямоугольника (r)
  
  fmt.Println("Длина окружности:",c.perimeter()) // вычисление длины окружности
  fmt.Println("периметр прямоугольника:",r.perimeter()) // вычисление периметра прямоугольника 
}
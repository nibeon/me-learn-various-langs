package main

import (
  "fmt"
  "os"
)

func main() {
  file, err := os.Open("test.txt") // открываем файл
  if err != nil {
    // если не открывает выводим ошибку
    // handle the rror here
    return
  }
  defer file.Close() // в конце - закрываем файл
  
  // получаем размер файла
  stat, err := file.Stat()
  if err != nil {
    return
  }
  // чтение содержимого файла
  bs := make([]byte, stat.Size())
  _, err = file.Read(bs)
  if err != nil {
    return
  }
  
  str := string(bs)
  fmt.Println(str) // выводим содержимое файла на экран
}
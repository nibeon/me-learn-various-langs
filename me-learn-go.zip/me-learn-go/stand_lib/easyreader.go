package main

import (
  "fmt"
  "io/ioutil" //подключаем утилиты для стандарного input-output
)

func main() {
  bs, err := ioutil.ReadFile("test.txt")
  if err != nil {
    return
  }
  str := string(bs)
  fmt.Println(str)
}
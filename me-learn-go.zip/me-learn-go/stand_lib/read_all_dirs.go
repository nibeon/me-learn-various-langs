package main

import (
  "fmt"
  "os"
  "path/filepath"
)

func main() {
  // читаем всё содержимое текущего каталога
  // включая вложенные каталоги
  // filepath.Walk - функция прохода по всем файлам по заданному пути
  filepath.Walk(".", func(path string, info os.FileInfo, err error) error {
    fmt.Println(path) // печатаем пути к файлам
    return nil
  })
}
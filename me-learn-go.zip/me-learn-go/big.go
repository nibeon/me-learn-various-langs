package main

import "fmt"

var a, b int64

func main() {
    a = 32132
    b = 42452
    fmt.Println(a * b)
}